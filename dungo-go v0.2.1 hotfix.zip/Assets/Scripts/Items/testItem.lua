function getInformation()
    name = "testItem"
    functionName = "t"
    numReturns = 1
    imageBounds = "0;142;22;157;"
    return imageBounds, numReturns, functionName, name
end

function t()
    
    return false
end
